package dao;

import java.util.List;
import model.Entity;

public interface IDao {

    public void addEntity(Entity entity);
    
    public void deleteEntity(Entity entity);

    public void updateEntity(Entity entity);
    
    public Entity selectById(long id, String tableName);

    public List<Entity> getListEntity(String table);



}
